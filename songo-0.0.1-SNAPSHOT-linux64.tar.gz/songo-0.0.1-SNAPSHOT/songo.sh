#!/bin/sh
exec java -jar $(dirname $0)/lib/songo-0.0.1-SNAPSHOT.jar
